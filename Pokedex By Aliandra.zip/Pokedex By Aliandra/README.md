# Pokédex App — Flutter

Aplikasi mobile Pokédex untuk Silph Co., dibuat dengan Flutter.

## Struktur Folder

```
pokedex_flutter/
├── lib/
│   ├── main.dart                  ← Entry point aplikasi
│   ├── models/
│   │   └── pokemon.dart           ← Model data Pokémon
│   ├── data/
│   │   └── pokemon_data.dart      ← List data 12 Pokémon
│   ├── utils/
│   │   └── type_colors.dart       ← Helper warna per tipe
│   ├── screens/
│   │   ├── home_screen.dart       ← Halaman utama (grid kartu)
│   │   └── detail_screen.dart     ← Halaman detail Pokémon
│   └── widgets/
│       └── pokemon_card.dart      ← Widget kartu di grid
└── pubspec.yaml
```

## Cara Menjalankan

### 1. Pastikan Flutter sudah terinstall
```bash
flutter --version
```
Kalau belum, download di: https://docs.flutter.dev/get-started/install

### 2. Buka folder project di VS Code
```bash
cd pokedex_flutter
code .
```

### 3. Install dependencies
```bash
flutter pub get
```

### 4. Jalankan aplikasi
```bash
flutter run
```
Pilih emulator Android / iOS, atau tekan `d` untuk device yang tersambung.

## Fitur
- Grid kartu Pokémon dengan warna berdasarkan tipe
- Tap kartu → halaman detail lengkap
- Base stats dengan progress bar berwarna
- Tampilan weakness, partner cocok, dan evolusi
