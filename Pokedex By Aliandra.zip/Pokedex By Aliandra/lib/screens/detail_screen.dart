import 'package:flutter/material.dart';
import '../models/pokemon.dart';
import '../utils/type_colors.dart';

class DetailScreen extends StatelessWidget {
  final Pokemon pokemon;

  const DetailScreen({super.key, required this.pokemon});

  @override
  Widget build(BuildContext context) {
    final primaryType = pokemon.types.first;
    final bgColor = TypeColors.background(primaryType);

    return Scaffold(
      backgroundColor: bgColor.withOpacity(0.3),
      appBar: AppBar(
        backgroundColor: bgColor.withOpacity(0.5),
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 18),
          color: const Color(0xFF1A1A1A),
          onPressed: () => Navigator.pop(context),
        ),
        title: Text(
          pokemon.name,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w500,
            color: Color(0xFF1A1A1A),
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header — gambar + nama + tipe
            Center(
              child: Column(
                children: [
                  SizedBox(
                    height: 160,
                    child: Image.asset(
                      pokemon.imagePath,
                      fit: BoxFit.contain,
                      errorBuilder: (_, __, ___) => const Icon(
                        Icons.catching_pokemon,
                        size: 80,
                        color: Color(0xFFD3D1C7),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    pokemon.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF1A1A1A),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 6,
                    children: pokemon.types
                        .map((t) => _TypeChip(type: t))
                        .toList(),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // Deskripsi
            _SectionCard(
              children: [
                _SectionLabel('Deskripsi'),
                const SizedBox(height: 6),
                Text(
                  pokemon.description,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Color(0xFF5F5E5A),
                    height: 1.6,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Role
            _SectionCard(
              children: [
                _SectionLabel('Role'),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: const Color(0xFFE1F5EE),
                    borderRadius: BorderRadius.circular(99),
                  ),
                  child: Text(
                    pokemon.role,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w500,
                      color: Color(0xFF0F6E56),
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Base Stats
            _SectionCard(
              children: [
                _SectionLabel('Base Stats'),
                const SizedBox(height: 12),
                ...pokemon.stats.entries
                    .map((e) => _StatBar(label: e.key, value: e.value)),
              ],
            ),
            const SizedBox(height: 12),

            // Kelemahan
            _SectionCard(
              children: [
                _SectionLabel('Kelemahan'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: pokemon.weakness
                      .map((w) => _DangerChip(label: w))
                      .toList(),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Partner
            _SectionCard(
              children: [
                _SectionLabel('Partner Cocok'),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: pokemon.partners
                      .map((p) => _PartnerChip(label: p))
                      .toList(),
                ),
              ],
            ),
            const SizedBox(height: 12),

            // Evolusi
            _SectionCard(
              children: [
                _SectionLabel('Evolusi'),
                const SizedBox(height: 6),
                Text(
                  pokemon.evolution,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Color(0xFF5F5E5A),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }
}

// ── Reusable widgets ──────────────────────────────────────

class _SectionCard extends StatelessWidget {
  final List<Widget> children;
  const _SectionCard({required this.children});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE0DED8), width: 0.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: children,
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  final String text;
  const _SectionLabel(this.text);

  @override
  Widget build(BuildContext context) {
    return Text(
      text.toUpperCase(),
      style: const TextStyle(
        fontSize: 11,
        fontWeight: FontWeight.w500,
        color: Color(0xFF888780),
        letterSpacing: 0.8,
      ),
    );
  }
}

class _TypeChip extends StatelessWidget {
  final String type;
  const _TypeChip({required this.type});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: TypeColors.background(type),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        type,
        style: TextStyle(
          fontSize: 13,
          fontWeight: FontWeight.w500,
          color: TypeColors.foreground(type),
        ),
      ),
    );
  }
}

class _DangerChip extends StatelessWidget {
  final String label;
  const _DangerChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFFCEBEB),
        borderRadius: BorderRadius.circular(99),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w500,
          color: Color(0xFFA32D2D),
        ),
      ),
    );
  }
}

class _PartnerChip extends StatelessWidget {
  final String label;
  const _PartnerChip({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: const Color(0xFFF1EFE8),
        borderRadius: BorderRadius.circular(99),
        border: Border.all(color: const Color(0xFFD3D1C7), width: 0.5),
      ),
      child: Text(
        label,
        style: const TextStyle(fontSize: 12, color: Color(0xFF5F5E5A)),
      ),
    );
  }
}

class _StatBar extends StatelessWidget {
  final String label;
  final int value;
  const _StatBar({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    const maxStat = 160;
    final ratio = (value / maxStat).clamp(0.0, 1.0);
    final color = TypeColors.statBar(label);

    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        children: [
          SizedBox(
            width: 52,
            child: Text(
              label,
              style: const TextStyle(fontSize: 12, color: Color(0xFF888780)),
            ),
          ),
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(99),
              child: LinearProgressIndicator(
                value: ratio,
                minHeight: 6,
                backgroundColor: const Color(0xFFF1EFE8),
                valueColor: AlwaysStoppedAnimation<Color>(color),
              ),
            ),
          ),
          const SizedBox(width: 8),
          SizedBox(
            width: 28,
            child: Text(
              '$value',
              textAlign: TextAlign.right,
              style: const TextStyle(fontSize: 12, color: Color(0xFF888780)),
            ),
          ),
        ],
      ),
    );
  }
}
