import 'package:flutter/material.dart';

class TypeColors {
  static Color background(String type) {
    switch (type.split(' ')[0]) {
      case 'Grass':   return const Color(0xFFEAF3DE);
      case 'Fire':    return const Color(0xFFFAECE7);
      case 'Water':   return const Color(0xFFE6F1FB);
      case 'Electric':return const Color(0xFFFAEEDA);
      case 'Ghost':   return const Color(0xFFEEEDFE);
      case 'Poison':  return const Color(0xFFEEEDFE);
      case 'Dragon':  return const Color(0xFFE6F1FB);
      case 'Flying':  return const Color(0xFFE1F5EE);
      case 'Normal':  return const Color(0xFFF1EFE8);
      case 'Fighting':return const Color(0xFFFAECE7);
      case 'Steel':   return const Color(0xFFF1EFE8);
      case 'Dark':    return const Color(0xFFD3D1C7);
      case 'Psychic': return const Color(0xFFFBEAF0);
      case 'Ice':     return const Color(0xFFE6F1FB);
      case 'Rock':    return const Color(0xFFF1EFE8);
      case 'Bug':     return const Color(0xFFEAF3DE);
      case 'Fairy':   return const Color(0xFFFBEAF0);
      default:        return const Color(0xFFF1EFE8);
    }
  }

  static Color foreground(String type) {
    switch (type.split(' ')[0]) {
      case 'Grass':   return const Color(0xFF3B6D11);
      case 'Fire':    return const Color(0xFF993C1D);
      case 'Water':   return const Color(0xFF185FA5);
      case 'Electric':return const Color(0xFF854F0B);
      case 'Ghost':   return const Color(0xFF3C3489);
      case 'Poison':  return const Color(0xFF3C3489);
      case 'Dragon':  return const Color(0xFF185FA5);
      case 'Flying':  return const Color(0xFF0F6E56);
      case 'Normal':  return const Color(0xFF5F5E5A);
      case 'Fighting':return const Color(0xFF993C1D);
      case 'Steel':   return const Color(0xFF444441);
      case 'Dark':    return const Color(0xFF2C2C2A);
      case 'Psychic': return const Color(0xFF993556);
      case 'Ice':     return const Color(0xFF185FA5);
      case 'Rock':    return const Color(0xFF5F5E5A);
      case 'Bug':     return const Color(0xFF3B6D11);
      case 'Fairy':   return const Color(0xFF993556);
      default:        return const Color(0xFF444441);
    }
  }

  static Color statBar(String stat) {
    switch (stat) {
      case 'HP':     return const Color(0xFF1D9E75);
      case 'Atk':    return const Color(0xFFD85A30);
      case 'Def':    return const Color(0xFF378ADD);
      case 'Sp.Atk': return const Color(0xFF7F77DD);
      case 'Sp.Def': return const Color(0xFF378ADD);
      case 'Spd':    return const Color(0xFFEF9F27);
      default:       return const Color(0xFF888780);
    }
  }
}
