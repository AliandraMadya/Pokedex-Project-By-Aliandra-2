class Pokemon {
  final String name;
  final String imagePath;
  final List<String> types;
  final String role;
  final String description;
  final Map<String, int> stats;
  final List<String> weakness;
  final List<String> partners;
  final String evolution;

  const Pokemon({
    required this.name,
    required this.imagePath,
    required this.types,
    required this.role,
    required this.description,
    required this.stats,
    required this.weakness,
    required this.partners,
    required this.evolution,
  });
}
